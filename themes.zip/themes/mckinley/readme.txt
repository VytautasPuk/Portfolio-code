McKinley WordPress Theme
A few things to know about this theme:

- For best results, featured images should be at least 1000px in width.

- Galleries in a post with gallery post format are automatically displayed as a slider. For best results, these images should be at least 1000px in width.